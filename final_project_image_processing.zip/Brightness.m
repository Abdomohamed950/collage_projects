function [image1] = Brightness (image0,offset)
image1= image0 + offset;
end
