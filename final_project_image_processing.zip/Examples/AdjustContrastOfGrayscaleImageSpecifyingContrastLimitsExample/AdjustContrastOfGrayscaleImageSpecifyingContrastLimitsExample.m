%% Adjust Contrast of Grayscale Image Specifying Contrast Limits
% 
%%
% Read a low-contrast grayscale image into the workspace and display it.

% Copyright 2015 The MathWorks, Inc.

I = imread('pout.tif');
imshow(I);
%%
% Adjust the contrast of the image, specifying contrast limits.
K = imadjust(I,[0.3 0.7],[]);
figure
imshow(K)